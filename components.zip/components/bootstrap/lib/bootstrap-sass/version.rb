module Bootstrap
  VERSION       = '3.3.6'
  BOOTSTRAP_SHA = '81df608a40bf0629a1dc08e584849bb1e43e0b7a'
end
